
#ifndef CTTwoMotorControl_h
#define CTTwoMotorControl_h

#include <avr/pgmspace.h>

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "CTTwoMotorPinID.h"

class CCTTwoMotorControl {
  //friend class CCTTwoMotorPinID;
public:
  unsigned int m_duration;  // time in milliseconds
  char m_directionM1;	// 'F' = forward, 'R' = reverse, 'B' = break, 'S' = stop
  char m_directionM2;	
  unsigned char m_speedM1;  // speed 0 through 255
  unsigned char m_speedM2;

public:
CCTTwoMotorControl();

CCTTwoMotorControl(unsigned int v_duration);

// v_duration: time in milliseconds
// v_directionM1, v_directionM2: 'F' forward, 'R' reverse, 
//                               'B' brake, 'S' stop
// v_speedM1, v_speedM2: 0 - 255, 0 = stop, 255 = fast
CCTTwoMotorControl(unsigned int v_duration, 
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2);

void Print();

void Set(unsigned int v_duration, 
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2);

// return 0 if not completed, 1 if completed
unsigned char Engage(CCTTwoMotorPinID& MP);

void Go(CCTTwoMotorPinID &MP,
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2);

void Go(CCTTwoMotorPinID &MP);	// go forever

private:
void motor(int nMotor, char command, int speed);
void motor_output (int output, int high_low, int speed);
void shiftWrite(int output, int high_low);

};

#endif
