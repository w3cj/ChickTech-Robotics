#include <avr/pgmspace.h>
#include "CTTwoMotorControl.h"

#ifndef GCTTwoMotorControlPreviousMillis
#define GCTTwoMotorControlPreviousMillis
// Arduino does not support static variables within a class so we will make a global variable
unsigned long g_CTTwoMotorControlPreviousMillis;
#endif

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

// Note: In order to brake a motor instead of letting it coast, the CTTwoMotorControl object must be created
// using the constructor that sets all the data members.

CCTTwoMotorControl::CCTTwoMotorControl() {
    g_CTTwoMotorControlPreviousMillis = 0;
    m_duration = 0;
    m_directionM1 = 'F';
    m_directionM2 = 'F';
    m_speedM1 = 0;
    m_speedM2 = 0;
}

CCTTwoMotorControl::CCTTwoMotorControl(unsigned int v_duration) {
    g_CTTwoMotorControlPreviousMillis = 0;
    m_duration = v_duration;
    m_directionM1 = 'F';
    m_directionM2 = 'F';
    m_speedM1 = 0;
    m_speedM2 = 0;
}

  // v_duration: time in milliseconds
  // v_directionM1, v_directionM2: positive - forward; negative - reverse; zero - brake
  // v_speedM1, v_speedM2: 0 - 255, 0 = stop, 255 = fast
CCTTwoMotorControl::CCTTwoMotorControl(unsigned int v_duration, 
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2) {
    g_CTTwoMotorControlPreviousMillis = 0;
    m_duration = v_duration;
    m_directionM1 = v_directionM1;
    m_directionM2 = v_directionM2;
    m_speedM1 = v_speedM1;
    m_speedM2 = v_speedM2;
}
  
void CCTTwoMotorControl::Print() {
    Serial.print("CCTTwoMotorControl Object: ");
    Serial.print("duration=");
    Serial.print(m_duration, DEC);
    Serial.print(" directionM1=");
    Serial.print(m_directionM1);
    Serial.print(" directionM2=");
    Serial.print(m_directionM2);
    Serial.print(" speedM1=");
    Serial.print(m_speedM1, DEC);
    Serial.print(" speedM2=");
    Serial.print(m_speedM2, DEC);
    Serial.println("");
}


  // return 0 if not completed, 1 if completed
unsigned char CCTTwoMotorControl::Engage(CCTTwoMotorPinID& MP) {
    unsigned long currMilliSec = millis();

    if(g_CTTwoMotorControlPreviousMillis == 0) {
    	Print();
    	g_CTTwoMotorControlPreviousMillis = currMilliSec;
    	Go(MP);
    }
    if(currMilliSec - g_CTTwoMotorControlPreviousMillis >= (unsigned long) m_duration) {
      g_CTTwoMotorControlPreviousMillis = 0;
      return 1;
    }
    return 0;
}


void CCTTwoMotorControl::Set(unsigned int v_duration, 
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2) {
    g_CTTwoMotorControlPreviousMillis = 0;
    m_duration = v_duration;
    m_directionM1 = v_directionM1;
    m_directionM2 = v_directionM2;
    m_speedM1 = v_speedM1;
    m_speedM2 = v_speedM2;
}


void CCTTwoMotorControl::Go(CCTTwoMotorPinID& MP) {
    unsigned int motorSpeedM1;
    unsigned int motorSpeedM2;
    
		// m_directionXX: 'F' forward, 'R' reverse, 'B' brake, 'S' stop (coast)
		// m_speedXX: 0..255  good numbers for movement are between 120 and 250
	
	  // Apply speed adjustment as a multiplier * 100 to compensate for weak 
	  // motors.
	  // It is better to decrease the power of a strong motor rather than 
	  // increase the power of a weak one because the speed (power) can never
	  // exceed 255.
		motorSpeedM1 = m_speedM1;
		motorSpeedM1 = (motorSpeedM1 * MP.adjustM1Speed) / 100;
		if(motorSpeedM1 > 255) motorSpeedM1 = 255;
		motorSpeedM2 = m_speedM2;
		motorSpeedM2 = (motorSpeedM2 * MP.adjustM2Speed) / 100;
		if(motorSpeedM2 > 255) motorSpeedM2 = 255;
	  
	  // We are going to assume that motors are connected to M1_A(+), M1_B(-)
	  // and M2_A(+), M2_B(-) (i.e. motor 1 and motor 2).
	  motor(1, m_directionM1, motorSpeedM1);
	  motor(2, m_directionM2, motorSpeedM2);
}
	

void CCTTwoMotorControl::Go(CCTTwoMotorPinID& MP, 
  char v_directionM1, unsigned char v_speedM1,
  char v_directionM2, unsigned char v_speedM2) {
    m_directionM1 = v_directionM1;
    m_directionM2 = v_directionM2;
    m_speedM1 = v_speedM1;
    m_speedM2 = v_speedM2;
    Go(MP);
}



// Initializing
// ------------
// There is no initialization function.
//
// The shiftWrite() has an automatic initializing.
// The PWM outputs are floating during startup, 
// that's okay for the Adafruit Motor Shield, it stays off.
// Using analogWrite() without pinMode() is valid.
//


// ---------------------------------
// motor
//
// Select the motor (1-4), the command, 
// and the speed (0-255).
// The commands are: 'F' = Forward, 'R' = Reverse, 'B' = Break, 'S' = Stop or Coast.
//
void CCTTwoMotorControl::motor(int nMotor, char command, int speed)
{
  int motorA, motorB;

	Serial.print(">>>motor: ");
	Serial.print(command);
	Serial.print(" ");
	Serial.println(speed, DEC);
  if (nMotor >= 1 && nMotor <= 4)
  {  
    switch (nMotor)
    {
    case 1:
      motorA   = MOTOR1_A;
      motorB   = MOTOR1_B;
      break;
    case 2:
      motorA   = MOTOR2_A;
      motorB   = MOTOR2_B;
      break;
    case 3:
      motorA   = MOTOR3_A;
      motorB   = MOTOR3_B;
      break;
    case 4:
      motorA   = MOTOR4_A;
      motorB   = MOTOR4_B;
      break;
    default:
      break;
    }

    switch (command)
    {
    case 'F':
      motor_output (motorA, HIGH, speed);
      motor_output (motorB, LOW, -1);     // -1: no PWM set
      break;
    case 'R':
      motor_output (motorA, LOW, speed);
      motor_output (motorB, HIGH, -1);    // -1: no PWM set
      break;
    case 'B':
      // The AdaFruit library didn't implement a brake.
      // The L293D motor driver ic doesn't have a good
      // brake anyway.
      // It uses transistors inside, and not mosfets.
      // Some use a software break, by using a short
      // reverse voltage.
      // This brake will try to brake, by enabling 
      // the output and by pulling both outputs to ground.
      // But it isn't a good break.
      motor_output (motorA, LOW, 255); // 255: fully on.
      motor_output (motorB, LOW, -1);  // -1: no PWM set
      break;
    case 'S':
      motor_output (motorA, LOW, 0);  // 0: output floating.
      motor_output (motorB, LOW, -1); // -1: no PWM set
      break;
    default:
      break;
    }
  }
}


// ---------------------------------
// motor_output
//
// The function motor_ouput uses the motor driver to
// drive normal outputs like lights, relays, solenoids, 
// DC motors (but not in reverse).
//
// It is also used as an internal helper function 
// for the motor() function.
//
// The high_low variable should be set 'HIGH' 
// to drive lights, etc.
// It can be set 'LOW', to switch it off, 
// but also a 'speed' of 0 will switch it off.
//
// The 'speed' sets the PWM for 0...255, and is for 
// both pins of the motor output.
//   For example, if motor 3 side 'A' is used to for a
//   dimmed light at 50% (speed is 128), also the 
//   motor 3 side 'B' output will be dimmed for 50%.
// Set to 0 for completelty off (high impedance).
// Set to 255 for fully on.
// Special settings for the PWM speed:
//    Set to -1 for not setting the PWM at all.
//
void CCTTwoMotorControl::motor_output (int output, int high_low, int speed)
{
  int motorPWM;

  switch (output)
  {
  case MOTOR1_A:
  case MOTOR1_B:
    motorPWM = MOTOR1_PWM;
    break;
  case MOTOR2_A:
  case MOTOR2_B:
    motorPWM = MOTOR2_PWM;
    break;
  case MOTOR3_A:
  case MOTOR3_B:
    motorPWM = MOTOR3_PWM;
    break;
  case MOTOR4_A:
  case MOTOR4_B:
    motorPWM = MOTOR4_PWM;
    break;
  default:
    // Use speed as error flag, -3333 = invalid output.
    speed = -3333;
    break;
  }

  if (speed != -3333)
  {
    // Set the direction with the shift register 
    // on the MotorShield, even if the speed = -1.
    // In that case the direction will be set, but
    // not the PWM.
    shiftWrite(output, high_low);

    // set PWM only if it is valid
    if (speed >= 0 && speed <= 255)    
    {
      analogWrite(motorPWM, speed);
    }
  }
}


// ---------------------------------
// shiftWrite
//
// The parameters are just like digitalWrite().
//
// The output is the pin 0...7 (the pin behind 
// the shift register).
// The second parameter is HIGH or LOW.
//
// There is no initialization function.
// Initialization is automatically done at the first
// time it is used.
//
void CCTTwoMotorControl::shiftWrite(int output, int high_low)
{
  static int latch_copy;
  static int shift_register_initialized = false;

  // Do the initialization on the fly, 
  // at the first time it is used.
  if (!shift_register_initialized)
  {
    // Set pins for shift register to output
    pinMode(MOTORLATCH, OUTPUT);
    pinMode(MOTORENABLE, OUTPUT);
    pinMode(MOTORDATA, OUTPUT);
    pinMode(MOTORCLK, OUTPUT);

    // Set pins for shift register to default value (low);
    digitalWrite(MOTORDATA, LOW);
    digitalWrite(MOTORLATCH, LOW);
    digitalWrite(MOTORCLK, LOW);
    // Enable the shift register, set Enable pin Low.
    digitalWrite(MOTORENABLE, LOW);

    // start with all outputs (of the shift register) low
    latch_copy = 0;

    shift_register_initialized = true;
  }

  // The defines HIGH and LOW are 1 and 0.
  // So this is valid.
  bitWrite(latch_copy, output, high_low);

  // Use the default Arduino 'shiftOut()' function to
  // shift the bits with the MOTORCLK as clock pulse.
  // The 74HC595 shiftregister wants the MSB first.
  // After that, generate a latch pulse with MOTORLATCH.
  shiftOut(MOTORDATA, MOTORCLK, MSBFIRST, latch_copy);
  delayMicroseconds(5);    // For safety, not really needed.
  digitalWrite(MOTORLATCH, HIGH);
  delayMicroseconds(5);    // For safety, not really needed.
  digitalWrite(MOTORLATCH, LOW);
}

