#include <avr/pgmspace.h>
#include "CTTwoMotorPinID.h"

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

CCTTwoMotorPinID::CCTTwoMotorPinID() {
    adjustM1Speed = 0;
    adjustM2Speed = 0;
}

CCTTwoMotorPinID::CCTTwoMotorPinID(int adjM1Speed, int adjM2Speed) {
    adjustM1Speed = adjM1Speed;
    adjustM2Speed = adjM2Speed;
}

void CCTTwoMotorPinID::Setup() {
}

